a=0.6
print("square number:",a*a)
print("cube number:",a*a*a)
