a=input("s:")
b=a.split()
n=len(b)
print("Number of words: ",n)
print(len(b[n-1]))

