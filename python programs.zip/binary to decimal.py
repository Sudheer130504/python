a=input("Enter the binary number:")
b="01"
for i in range(len(a)):
    binary=True
if a[i] not in b:
    print("Invalid input")
    binary=False
if binary:
    decimal = int (a,2)
    octal = oct (decimal)
    hexa = hex (decimal)
print("Decimal Equivalent=",decimal)
print("Octal Equivalent=",octal)
print("Hexa Equivalent=",hexa)
    

