a=7
b=9
c=-8
d=-6
print("the average of positive number:",a+b/2)
print("the average of negative number:",c-d/2)
