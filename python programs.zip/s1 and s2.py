s1=input("enter the elements:")
s2=input("enter the elements:")
def removeCommonWords(s1,s2):
      com =[]
st1=list(s1.split())
st2=list(s2.split())
for i in st1:
    if i in st2:
        st1.remove(i)
        st2.remove(i)
        com.append(i)
        continue
print(*st1)
print(*st2)
print("common words",*com)
sentence1 = input("Enter string1: ")
sentence2 = input("Enter string2: ")
removeCommonWords(s1,s2)

